﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OpenTokSDK;


namespace FifthAssesmentUpdated.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VideoController : ControllerBase
    {
        private const string ApiKey = "1dea0a2c"; 
        private const string ApiSecret = "hOtsTKu46RyJJ8Ie";

        [HttpGet("session")]
        public IActionResult GetSessionAndToken()
        {
            try
            {
                var opentok = new OpenTok(Convert.ToInt32(ApiKey),ApiSecret);

                
                var session = opentok.CreateSession(mediaMode: MediaMode.ROUTED);

                var expireTime = (int)(DateTime.UtcNow.AddHours(24) - new DateTime(1970, 1, 1)).TotalSeconds;
                var token = session.GenerateToken(role: Role.PUBLISHER, expireTime: expireTime);

                return Ok(new
                {
                    apiKey = ApiKey,
                    sessionId = session.Id,
                    token = token
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}


