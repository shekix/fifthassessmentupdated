import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  http = inject(HttpClient)
  constructor() { }

  private RegistrationUrl = 'https://localhost:7026/api/Registration/CreateUser';
  private LoginUrl = 'https://localhost:7026/api/Registration/LoginUser';
  private verifyUrl = 'https://localhost:7026/api/Registration/VerifyOtp';
  private videoUrl = 'https://localhost:7026/api/Video/session';

  registerUser(user:any):Observable<any>{
    return this.http.post<any>(this.RegistrationUrl,user,{responseType:'text' as 'json'} )
  }

  loginUser(user:any):Observable<any>{
    return this.http.post<any>(this.LoginUrl,user,{responseType :'text' as 'json'});
  }

  isLoggedIn(){
    return localStorage.getItem("access_token") ? true : false;
  }

  verifyUser(user:any){
    return this.http.post<any>(this.verifyUrl,user,{responseType :'text' as 'json'});
  }

  getSessionDetails(): Observable<any> {
    return this.http.get<any>(this.videoUrl);
  }

}
