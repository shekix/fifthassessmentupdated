import { CanActivateFn } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { inject } from '@angular/core';

export const authguardGuard: CanActivateFn = (route, state) => {
  var service = inject(ApiService);

  return service.isLoggedIn();
};
