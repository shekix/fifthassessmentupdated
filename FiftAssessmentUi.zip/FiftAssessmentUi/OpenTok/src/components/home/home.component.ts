import { Component } from '@angular/core';
import { ApiService } from '../../../services/api.service';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
declare const OT: any;

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  sessionId: string = '';
  token: string = '';
  apiKey: string = '';
  session: any;
  constructor(private videoService: ApiService) {}

  ngOnInit(): void {
    this.videoService.getSessionDetails().subscribe(
      (data) => {
        this.apiKey = data.apiKey;
        this.sessionId = data.sessionId;
        this.token = data.token;

        this.initializeSession();
      },
      (error) => {
        console.error('Error fetching session details:', error);
      }
    );
  }

  initializeSession(): void {
    // Initialize OpenTok session
    this.session = OT.initSession(this.apiKey, this.sessionId);

    // Wrap the session.connect() call in an observable
    this.connectSession(this.token).subscribe({
      next: () => {
        console.log('Connected to session.');
        this.startPublishing();
      },
      error: (err) => {
        console.error('Error connecting to session:', err);
      }
    });

    // Subscribe to incoming streams
    this.session.on('streamCreated', (event: any) => {
      this.subscribeToStream(event.stream);
    });
  }

  // Wrap connect function in Observable
  connectSession(token: string): Observable<any> {
    return new Observable((observer) => {
      this.session.connect(token, (error: any) => {
        if (error) {
          observer.error(error);
        } else {
          observer.next();
          observer.complete();
        }
      });
    }).pipe(
      catchError((err) => {
        console.error('Error during session connection:', err);
        throw err;
      })
    );
  }

  // Start publishing to the session
  startPublishing(): void {
    const publisher = OT.initPublisher('publisher', {
      insertMode: 'append',
      width: '100%',
      height: '100%',
    });

    this.session.publish(publisher, (error: any) => {
      if (error) {
        console.error('Error publishing stream:', error.message);
      }
    });
  }

  // Subscribe to a stream
  subscribeToStream(stream: any): void {
    this.session.subscribe(stream, 'subscriber', {
      insertMode: 'append',
      width: '100%',
      height: '100%',
    }, (error: any) => {
      if (error) {
        console.error('Error subscribing to stream:', error.message);
      }
    });
  }
}
