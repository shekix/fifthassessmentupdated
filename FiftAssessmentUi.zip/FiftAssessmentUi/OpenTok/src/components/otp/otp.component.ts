import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { JwtHelperService } from '@auth0/angular-jwt';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../../../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-otp',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule],
  templateUrl: './otp.component.html',
  styleUrl: './otp.component.css'
})
export class OtpComponent {
  api:any;
  otpForm = new FormGroup({
    otp : new FormControl('',[Validators.required])
  })

  constructor(api:ApiService, private router:Router){
    this.api = api;
  }

  currentUser : BehaviorSubject<any> = new BehaviorSubject(null);
  jwtHelperService = new JwtHelperService();

  verify(){

    var data = {
      email:localStorage.getItem("email"),
      otp:this.otpForm.value.otp
    }

    this.api.verifyUser(data).subscribe((res:any)=>{
      if(res=='InvalidOTP'){
        alert("invalid otp");
        this.api.isLoggedIn(false);
      }
      else{
        this.setToken(res);
        this.api.isLoggedIn();
        this.router.navigate(['/home']);
      }
    })
  }


    setToken(token:string){
    localStorage.setItem("access_token",token);
    this.loadCurrentUser();
  }
  
  loadCurrentUser(){
    const token = localStorage.getItem("access_token");
    const userInfo = token != null? this.jwtHelperService.decodeToken(token) : null;
    const data = userInfo ? {
      id:userInfo.id,
      firstname:userInfo.FirstName,
      lastName:userInfo.lastName,
      email:userInfo.Email
    }:null;
  
   this.currentUser.next(data);
   console.log(this.currentUser);
   
  }
}
