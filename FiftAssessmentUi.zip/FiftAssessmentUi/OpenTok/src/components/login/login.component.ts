import { Component } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiService } from '../../../services/api.service';
import { Router, RouterLink } from '@angular/router';
import {JwtHelperService} from '@auth0/angular-jwt';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  api:any;
  Agentid:any;
  //currentUser : BehaviorSubject<any> = new BehaviorSubject(null);
  //jwtHelperService = new JwtHelperService();
  constructor(api:ApiService, private router:Router){
  this.api = api;
  }
  
  loginForm = new FormGroup({
    email : new FormControl('',[Validators.required,Validators.email]),
    password:new FormControl('',[Validators.required]),
  
  })
  
  get Email() : FormControl{
    return this.loginForm.get('email') as FormControl;
  } 
  get Password() : FormControl{
    return this.loginForm.get('password') as FormControl;
  } 
  isUserValid:boolean = false;
  



  onLogin(){

    var data = {
      email:this.loginForm.value.email,
      password:this.loginForm.value.password
    }
    this.api.loginUser(data).subscribe((res:any)=>{
      if(res =='Failure'){
        alert('Invalid credentials');
        // this.isUserValid = false;
        // this.api.isLoggedIn(this.isUserValid);
      }else{
        localStorage.setItem("email",data.email != null?data.email:'string')
        this.router.navigate(['/otp']);
        alert("otp sent to mail");
        //this.setToken(res);
        //this.isUserValid=true;
        //localStorage.setItem("id",this.currentUser.value.id);
        // this.router.navigate(['/home',{data:this.currentUser.value.id}]);
        
      }
    })
  }
  
  // setToken(token:string){
  //   localStorage.setItem("access_token",token);
  //   this.loadCurrentUser();
  // }
  
  // loadCurrentUser(){
  //   const token = localStorage.getItem("access_token");
  //   const userInfo = token != null? this.jwtHelperService.decodeToken(token) : null;
  //   const data = userInfo ? {
  //     id:userInfo.id,
  //     firstname:userInfo.FirstName,
  //     lastName:userInfo.lastName,
  //     email:userInfo.Email
  //   }:null;
  
   // this.currentUser.next(data);
  
    // this.userservice.setCurrentUser(data);
    //console.log(this.currentUser.value.id);
    
}

